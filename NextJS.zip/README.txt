NextJS v14+
Drop files from zip to project folder

Install axios
npm i axios

