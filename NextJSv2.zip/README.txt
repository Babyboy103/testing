NextJS v14+
Drop files from zip to project folder

Install axios
npm i axios

If something doesn't work with the middleware file, replace it with middleware v2, just be sure to change its name to middleware (middleware v2 > middleware)